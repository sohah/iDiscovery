package daikon.dcomp;

/**
 * Classes implementing this interface have been instrumented by DynComp
 * and have implemented a clone method.
 */
public interface DCompClone {
}
