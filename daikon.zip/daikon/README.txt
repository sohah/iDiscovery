This is the distribution of the Daikon invariant detector,
Daikon version 4.6.4, released June 23, 2010.

For documentation, including installation instructions, see the "doc"
subdirectory.  You can start with file
  doc/index.html

