This directory contains documentation for the Daikon invariant detector,
Daikon version 4.6.4, released June 23, 2010.

See file
  index.html
for a list of the documentation available in this directory.
