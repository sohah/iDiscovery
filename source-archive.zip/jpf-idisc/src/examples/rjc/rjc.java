package rjc;

import gov.nasa.jpf.vm.Verify;
public class rjc {
	public Reaction_Jet_Control0 Reaction_Jet_Control_100000006_class_member0 = new Reaction_Jet_Control0();

	public void Main0(double[] In1_2, double[] In2_3, double[] Out1_4, double[] Out2_5) {
		Reaction_Jet_Control_100000006_class_member0.Main1(In1_2, In2_3, Out1_4, Out2_5);
	}

	public void Init2() {
		Reaction_Jet_Control_100000006_class_member0.Init3();
	}

	// Added by hand so that symbolic pathfinder can be used
	public void MainSymbolic(double in1_0, double in1_1, double in1_2, double in2_0, double in2_1, double in2_2, double[] out1, double[] out2) {

		// iDiscovery: new variables introduced by iDiscovery
		double[] iDiscovery_PreVariable_4=this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554;
		Chart iDiscovery_PreVariable_38=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Chart_member12;
		double iDiscovery_PreVariable_12=in2_2;
		double[] iDiscovery_PreVariable_5=this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_7588;
		double[] iDiscovery_PreVariable_6=this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_11614;
		double iDiscovery_PreVariable_31=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain1082;
		ObserverAutomata iDiscovery_PreVariable_56=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.ObserverAutomata_member12;
		double[] iDiscovery_PreVariable_60=out2;
		double iDiscovery_PreVariable_28=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain1040;
		double[] iDiscovery_PreVariable_59=out1;
		int iDiscovery_PreVariable_62=daikon.Quant.size(out1);
		double[][] iDiscovery_PreVariable_2=this.Reaction_Jet_Control_100000006_class_member0.Value463;
		Subsystem213 iDiscovery_PreVariable_53=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Subsystem2_100000433_class_member9;
		double iDiscovery_PreVariable_21=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain918;
		Jet_On_TIme_Counter10 iDiscovery_PreVariable_39=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Jet_On_TIme_Counter_100000127_class_member13;
		Chart iDiscovery_PreVariable_47=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Chart_member12;
		double iDiscovery_PreVariable_32=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain1077;
		Subsystem35 iDiscovery_PreVariable_34=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Subsystem3_100000163_class_member8;
		int iDiscovery_PreVariable_64=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.Value495);
		SimpleCounter iDiscovery_PreVariable_51=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.SimpleCounter_member7;
		int iDiscovery_PreVariable_66=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556);
		int iDiscovery_PreVariable_67=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_7588);
		Subsystem8 iDiscovery_PreVariable_37=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Subsystem_100000160_class_member11;
		double iDiscovery_PreVariable_72=this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557;
		double iDiscovery_PreVariable_20=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain1195;
		double iDiscovery_PreVariable_29=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain1035;
		double iDiscovery_PreVariable_71=in1_0;
		int iDiscovery_PreVariable_61=daikon.Quant.size(out2);
		Chart iDiscovery_PreVariable_57=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Chart_member13;
		Subsystem312 iDiscovery_PreVariable_52=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Subsystem3_100000434_class_member8;
		Jet_On_TIme_Counter18 iDiscovery_PreVariable_58=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Jet_On_TIme_Counter_100000397_class_member14;
		int iDiscovery_PreVariable_65=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554);
		double iDiscovery_PreVariable_10=in2_0;
		Subsystem114 iDiscovery_PreVariable_54=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Subsystem1_100000432_class_member10;
		double iDiscovery_PreVariable_11=in2_1;
		SimpleCounter iDiscovery_PreVariable_33=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.SimpleCounter_member7;
		Subsystem221 iDiscovery_PreVariable_44=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Subsystem2_100000715_class_member9;
		double iDiscovery_PreVariable_26=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940;
		double[] iDiscovery_PreVariable_9=this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_12616;
		double iDiscovery_PreVariable_15=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value801;
		double iDiscovery_PreVariable_27=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030;
		double iDiscovery_PreVariable_17=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913;
		Jet_On_TIme_Counter25 iDiscovery_PreVariable_48=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Jet_On_TIme_Counter_100000680_class_member13;
		double iDiscovery_PreVariable_41=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948;
		int iDiscovery_PreVariable_68=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_8590);
		Yaw_Control_Law1 iDiscovery_PreVariable_13=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15;
		double iDiscovery_PreVariable_25=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value932;
		double[][] iDiscovery_PreVariable_3=this.Reaction_Jet_Control_100000006_class_member0.Value495;
		Subsystem320 iDiscovery_PreVariable_43=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Subsystem3_100000716_class_member8;
		double[] iDiscovery_PreVariable_7=this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556;
		Subsystem23 iDiscovery_PreVariable_46=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Subsystem_100000713_class_member11;
		double iDiscovery_PreVariable_30=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072;
		double iDiscovery_PreVariable_19=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain923;
		int iDiscovery_PreVariable_63=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.Value463);
		Reaction_Jet_Control0 iDiscovery_PreVariable_0=this.Reaction_Jet_Control_100000006_class_member0;
		u_Control_Law3 iDiscovery_PreVariable_49=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17;
		double iDiscovery_PreVariable_18=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1188;
		Subsystem17 iDiscovery_PreVariable_36=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Subsystem1_100000161_class_member10;
		SimpleCounter iDiscovery_PreVariable_42=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.SimpleCounter_member7;
		Subsystem122 iDiscovery_PreVariable_45=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Subsystem1_100000714_class_member10;
		int iDiscovery_PreVariable_70=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_12616);
		double iDiscovery_PreVariable_24=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value936;
		v_Control_Law2 iDiscovery_PreVariable_40=this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16;
		double iDiscovery_PreVariable_22=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain1210;
		double[] iDiscovery_PreVariable_8=this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_8590;
		Subsystem26 iDiscovery_PreVariable_35=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Subsystem2_100000162_class_member9;
		double iDiscovery_PreVariable_50=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944;
		double iDiscovery_PreVariable_14=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793;
		Subsystem15 iDiscovery_PreVariable_55=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Subsystem_100000431_class_member11;
		double iDiscovery_PreVariable_16=this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value797;
		double[][] iDiscovery_PreVariable_1=this.Reaction_Jet_Control_100000006_class_member0.Value431;
		int iDiscovery_PreVariable_69=daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_11614);
		double iDiscovery_PreVariable_23=this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928;

		// iDiscovery: pre-condition invariants injected by iDiscovery
		if(Verify.getBoolean()){
			if (Verify.getCounter(1) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, in2_1))) {
				Verify.incrementCounter(1);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(2) < 1&& !(daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, in1_0))) {
				Verify.incrementCounter(2);
				throw new AssertionError("daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, in1_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(3) < 1&& !(daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, in1_0))) {
				Verify.incrementCounter(3);
				throw new AssertionError("daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, in1_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(4) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, in2_1))) {
				Verify.incrementCounter(4);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(5) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, 0.005235987755982988))) {
				Verify.incrementCounter(5);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, 0.005235987755982988)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(6) < 1&& !(daikon.Quant.subsetOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { -10.0, 10.0 }))) {
				Verify.incrementCounter(6);
				throw new AssertionError("daikon.Quant.subsetOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { -10.0, 10.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(7) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, in2_2))) {
				Verify.incrementCounter(7);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(8) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, in2_1))) {
				Verify.incrementCounter(8);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(9) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, 0.0))) {
				Verify.incrementCounter(9);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, 0.0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(10) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, in2_1))) {
				Verify.incrementCounter(10);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(11) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592))) {
				Verify.incrementCounter(11);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(12) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, 0.18181818181818185))) {
				Verify.incrementCounter(12);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, 0.18181818181818185)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(13) < 1&& !(daikon.Quant.pairwiseGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, out2))) {
				Verify.incrementCounter(13);
				throw new AssertionError("daikon.Quant.pairwiseGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, out2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(14) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, in2_2))) {
				Verify.incrementCounter(14);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(15) < 1&& !(daikon.Quant.fuzzy.eq(in1_0, in1_1))) {
				Verify.incrementCounter(15);
				throw new AssertionError("daikon.Quant.fuzzy.eq(in1_0, in1_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(16) < 1&& !(daikon.Quant.fuzzy.lte(in1_0, in2_1))) {
				Verify.incrementCounter(16);
				throw new AssertionError("daikon.Quant.fuzzy.lte(in1_0, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(17) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, in2_1))) {
				Verify.incrementCounter(17);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(18) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618))) {
				Verify.incrementCounter(18);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(19) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, in2_0))) {
				Verify.incrementCounter(19);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(20) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, in2_0))) {
				Verify.incrementCounter(20);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(21) < 1&& !(daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.Value431) == daikon.Quant.size(out2))) {
				Verify.incrementCounter(21);
				throw new AssertionError("daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.Value431) == daikon.Quant.size(out2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(22) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, in2_0))) {
				Verify.incrementCounter(22);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(23) < 1&& !(daikon.Quant.memberOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557 , out2 ))) {
				Verify.incrementCounter(23);
				throw new AssertionError("daikon.Quant.memberOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557 , out2 )");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(24) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, in2_2))) {
				Verify.incrementCounter(24);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(25) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, in2_0))) {
				Verify.incrementCounter(25);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(26) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_9591))) {
				Verify.incrementCounter(26);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_9591)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(27) < 1&& !(daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556))) {
				Verify.incrementCounter(27);
				throw new AssertionError("daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(28) < 1&& !(daikon.Quant.memberOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557 , out1 ))) {
				Verify.incrementCounter(28);
				throw new AssertionError("daikon.Quant.memberOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557 , out1 )");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(29) < 1&& !(daikon.Quant.fuzzy.eq(in1_0, -2.147483648E9))) {
				Verify.incrementCounter(29);
				throw new AssertionError("daikon.Quant.fuzzy.eq(in1_0, -2.147483648E9)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(30) < 1&& !(daikon.Quant.fuzzy.eq(in1_0, in1_2))) {
				Verify.incrementCounter(30);
				throw new AssertionError("daikon.Quant.fuzzy.eq(in1_0, in1_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(31) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, in2_0))) {
				Verify.incrementCounter(31);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(32) < 1&& !(daikon.Quant.fuzzy.lte(in1_0, in2_2))) {
				Verify.incrementCounter(32);
				throw new AssertionError("daikon.Quant.fuzzy.lte(in1_0, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(33) < 1&& !(daikon.Quant.eltsEqual(out1, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557))) {
				Verify.incrementCounter(33);
				throw new AssertionError("daikon.Quant.eltsEqual(out1, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(34) < 1&& !(daikon.Quant.eltsEqual(out2, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557))) {
				Verify.incrementCounter(34);
				throw new AssertionError("daikon.Quant.eltsEqual(out2, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(35) < 1&& !(daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.Value431)-1 == daikon.Quant.size(out1))) {
				Verify.incrementCounter(35);
				throw new AssertionError("daikon.Quant.size(this.Reaction_Jet_Control_100000006_class_member0.Value431)-1 == daikon.Quant.size(out1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(36) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, in2_0))) {
				Verify.incrementCounter(36);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(37) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, new double[] { 1.0, 0.0 }))) {
				Verify.incrementCounter(37);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, new double[] { 1.0, 0.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(38) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, 0.5))) {
				Verify.incrementCounter(38);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, 0.5)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(39) < 1&& !(daikon.Quant.eltsGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557))) {
				Verify.incrementCounter(39);
				throw new AssertionError("daikon.Quant.eltsGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(40) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, in2_2))) {
				Verify.incrementCounter(40);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(41) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, in2_0))) {
				Verify.incrementCounter(41);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(42) < 1&& !(daikon.Quant.eltsEqual(out1, 0.0))) {
				Verify.incrementCounter(42);
				throw new AssertionError("daikon.Quant.eltsEqual(out1, 0.0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(43) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, in2_2))) {
				Verify.incrementCounter(43);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(44) < 1&& !(daikon.Quant.memberOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557 , this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556 ))) {
				Verify.incrementCounter(44);
				throw new AssertionError("daikon.Quant.memberOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557 , this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556 )");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(45) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, 0.006285533905932738))) {
				Verify.incrementCounter(45);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, 0.006285533905932738)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(46) < 1&& !(daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554))) {
				Verify.incrementCounter(46);
				throw new AssertionError("daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(47) < 1&& !(daikon.Quant.pairwiseEqual(out1, new double[] { 0.0 }))) {
				Verify.incrementCounter(47);
				throw new AssertionError("daikon.Quant.pairwiseEqual(out1, new double[] { 0.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(48) < 1&& !(daikon.Quant.eltsEqual(out2, 0.0))) {
				Verify.incrementCounter(48);
				throw new AssertionError("daikon.Quant.eltsEqual(out2, 0.0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(49) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, 6.25E-4))) {
				Verify.incrementCounter(49);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, 6.25E-4)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(50) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558))) {
				Verify.incrementCounter(50);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(51) < 1&& !(daikon.Quant.pairwiseEqual(out2, new double[] { 0.0, 0.0 }))) {
				Verify.incrementCounter(51);
				throw new AssertionError("daikon.Quant.pairwiseEqual(out2, new double[] { 0.0, 0.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(52) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, 2.0))) {
				Verify.incrementCounter(52);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, 2.0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(53) < 1&& !(daikon.Quant.eltsLT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793))) {
				Verify.incrementCounter(53);
				throw new AssertionError("daikon.Quant.eltsLT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(54) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_13617))) {
				Verify.incrementCounter(54);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_13617)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(55) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { 10.0, -10.0 }))) {
				Verify.incrementCounter(55);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { 10.0, -10.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(56) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, in2_0))) {
				Verify.incrementCounter(56);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, in2_0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(57) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, in2_2))) {
				Verify.incrementCounter(57);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(58) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, in2_2))) {
				Verify.incrementCounter(58);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, in2_2)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(59) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, in2_1))) {
				Verify.incrementCounter(59);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(60) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, 7.855339059327378E-4))) {
				Verify.incrementCounter(60);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, 7.855339059327378E-4)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(61) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, in2_1))) {
				Verify.incrementCounter(61);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, in2_1)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(62) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, 0.055))) {
				Verify.incrementCounter(62);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, 0.055)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(63) < 1&& !(daikon.Quant.fuzzy.lte(in1_0, in2_0))) {
				Verify.incrementCounter(63);
				throw new AssertionError("daikon.Quant.fuzzy.lte(in1_0, in2_0)");
			}
			Verify.ignoreIf(true);
		}


		// original method body begins
		double[] in1 = new double[3];
		double[] in2 = new double[3];

		in1[0] = in1_0;
		in1[1] = in1_1;
		in1[2] = in1_2;

		in2[0] = in2_0;
		in2[1] = in2_1;
		in2[2] = in2_2;

		this.Reaction_Jet_Control_100000006_class_member0.Main1(in1, in2, out1, out2);
		// original method body ends


		// iDiscovery: post-condition invariants injected by iDiscovery
		if(Verify.getBoolean()){
			if (Verify.getCounter(64) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, iDiscovery_PreVariable_16))) {
				Verify.incrementCounter(64);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, \\old(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value797))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(65) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(65);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(66) < 1&& !(this.Reaction_Jet_Control_100000006_class_member0 == iDiscovery_PreVariable_0)) {
				Verify.incrementCounter(66);
				throw new AssertionError("this.Reaction_Jet_Control_100000006_class_member0 == \\old(this.Reaction_Jet_Control_100000006_class_member0)");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(67) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(67);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}




		if(Verify.getBoolean()){
			if (Verify.getCounter(68) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, 0.18181818181818185))) {
				Verify.incrementCounter(68);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, 0.18181818181818185)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(69) < 1&& !(daikon.Quant.pairwiseGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, out2))) {
				Verify.incrementCounter(69);
				throw new AssertionError("daikon.Quant.pairwiseGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, out2)");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(70) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(70);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(71) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(71);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(72) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940))) {
				Verify.incrementCounter(72);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(73) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928))) {
				Verify.incrementCounter(73);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(74) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(74);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(75) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, iDiscovery_PreVariable_7))) {
				Verify.incrementCounter(75);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, \\old(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(76) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072))) {
				Verify.incrementCounter(76);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(77) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793))) {
				Verify.incrementCounter(77);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(78) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944))) {
				Verify.incrementCounter(78);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944)");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(79) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, iDiscovery_PreVariable_71))) {
				Verify.incrementCounter(79);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, \\old(in1_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(80) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_22))) {
				Verify.incrementCounter(80);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain1210))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(81) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(81);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(82) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, iDiscovery_PreVariable_26))) {
				Verify.incrementCounter(82);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, \\old(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940))");
			}
			Verify.ignoreIf(true);
		}





		if(Verify.getBoolean()){
			if (Verify.getCounter(83) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030))) {
				Verify.incrementCounter(83);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(84) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(84);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(85) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948))) {
				Verify.incrementCounter(85);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(86) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928))) {
				Verify.incrementCounter(86);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(87) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, new double[] { 1.0, 0.0 }))) {
				Verify.incrementCounter(87);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, new double[] { 1.0, 0.0 })");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(88) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, iDiscovery_PreVariable_14))) {
				Verify.incrementCounter(88);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, \\old(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793))");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(89) < 1&& !(daikon.Quant.eltsEqual(out2, iDiscovery_PreVariable_72))) {
				Verify.incrementCounter(89);
				throw new AssertionError("daikon.Quant.eltsEqual(out2, \\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(90) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.Value463, iDiscovery_PreVariable_2))) {
				Verify.incrementCounter(90);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.Value463, \\old(this.Reaction_Jet_Control_100000006_class_member0.Value463))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(91) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_19))) {
				Verify.incrementCounter(91);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain923))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(92) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(92);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}




		if(Verify.getBoolean()){
			if (Verify.getCounter(93) < 1&& !(daikon.Quant.eltsEqual(out1, 0.0))) {
				Verify.incrementCounter(93);
				throw new AssertionError("daikon.Quant.eltsEqual(out1, 0.0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(94) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, iDiscovery_PreVariable_24))) {
				Verify.incrementCounter(94);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, \\old(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value936))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(95) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, iDiscovery_PreVariable_32))) {
				Verify.incrementCounter(95);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, \\old(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain1077))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(96) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928))) {
				Verify.incrementCounter(96);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(97) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, iDiscovery_PreVariable_28))) {
				Verify.incrementCounter(97);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, \\old(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain1040))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(98) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(98);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(99) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(99);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(100) < 1&& !(daikon.Quant.eltsEqual(out2, 0.0))) {
				Verify.incrementCounter(100);
				throw new AssertionError("daikon.Quant.eltsEqual(out2, 0.0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(101) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, iDiscovery_PreVariable_15))) {
				Verify.incrementCounter(101);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, \\old(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value801))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(102) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, 6.25E-4))) {
				Verify.incrementCounter(102);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, 6.25E-4)");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(103) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, iDiscovery_PreVariable_41))) {
				Verify.incrementCounter(103);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, \\old(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(104) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(104);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(105) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_18))) {
				Verify.incrementCounter(105);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1188))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(106) < 1&& !(daikon.Quant.pairwiseEqual(out2, iDiscovery_PreVariable_60))) {
				Verify.incrementCounter(106);
				throw new AssertionError("daikon.Quant.pairwiseEqual(out2, \\old(out2))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(107) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, 7.855339059327378E-4))) {
				Verify.incrementCounter(107);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, 7.855339059327378E-4)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(108) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, iDiscovery_PreVariable_25))) {
				Verify.incrementCounter(108);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, \\old(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value932))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(109) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(109);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}





		if(Verify.getBoolean()){
			if (Verify.getCounter(110) < 1&& !(daikon.Quant.memberOf(iDiscovery_PreVariable_72 , this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556 ))) {
				Verify.incrementCounter(110);
				throw new AssertionError("daikon.Quant.memberOf(\\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557) , this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556 )");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(111) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, iDiscovery_PreVariable_29))) {
				Verify.incrementCounter(111);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, \\old(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain1035))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(112) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, 0.005235987755982988))) {
				Verify.incrementCounter(112);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, 0.005235987755982988)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(113) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(113);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(114) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072))) {
				Verify.incrementCounter(114);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(115) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, iDiscovery_PreVariable_30))) {
				Verify.incrementCounter(115);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, \\old(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072))");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(116) < 1&& !(daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, iDiscovery_PreVariable_71))) {
				Verify.incrementCounter(116);
				throw new AssertionError("daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, \\old(in1_0))");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(117) < 1&& !(daikon.Quant.subsetOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { -10.0, 10.0 }))) {
				Verify.incrementCounter(117);
				throw new AssertionError("daikon.Quant.subsetOf(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { -10.0, 10.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(118) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(118);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(119) < 1&& !(daikon.Quant.memberOf(iDiscovery_PreVariable_72 , out1 ))) {
				Verify.incrementCounter(119);
				throw new AssertionError("daikon.Quant.memberOf(\\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557) , out1 )");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(120) < 1&& !(daikon.Quant.eltsEqual(out1, iDiscovery_PreVariable_72))) {
				Verify.incrementCounter(120);
				throw new AssertionError("daikon.Quant.eltsEqual(out1, \\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(121) < 1&& !(daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, iDiscovery_PreVariable_71))) {
				Verify.incrementCounter(121);
				throw new AssertionError("daikon.Quant.eltsGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, \\old(in1_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(122) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, iDiscovery_PreVariable_5))) {
				Verify.incrementCounter(122);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, \\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_7588))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(123) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913))) {
				Verify.incrementCounter(123);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913)");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(124) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_17))) {
				Verify.incrementCounter(124);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(125) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_13617, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(125);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_13617, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(126) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940))) {
				Verify.incrementCounter(126);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(127) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(127);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}




		if(Verify.getBoolean()){
			if (Verify.getCounter(128) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030))) {
				Verify.incrementCounter(128);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(129) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(129);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(130) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, iDiscovery_PreVariable_31))) {
				Verify.incrementCounter(130);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072, \\old(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain1082))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(131) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.Value431, iDiscovery_PreVariable_1))) {
				Verify.incrementCounter(131);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.Value431, \\old(this.Reaction_Jet_Control_100000006_class_member0.Value431))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(132) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944))) {
				Verify.incrementCounter(132);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(133) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, iDiscovery_PreVariable_71))) {
				Verify.incrementCounter(133);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, \\old(in1_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(134) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, iDiscovery_PreVariable_12))) {
				Verify.incrementCounter(134);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, \\old(in2_2))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(135) < 1&& !(daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556))) {
				Verify.incrementCounter(135);
				throw new AssertionError("daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(136) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, iDiscovery_PreVariable_6))) {
				Verify.incrementCounter(136);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, \\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_11614))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(137) < 1&& !(daikon.Quant.eltsGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, iDiscovery_PreVariable_72))) {
				Verify.incrementCounter(137);
				throw new AssertionError("daikon.Quant.eltsGTE(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, \\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(138) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(138);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(139) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.Value495, iDiscovery_PreVariable_3))) {
				Verify.incrementCounter(139);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.Value495, \\old(this.Reaction_Jet_Control_100000006_class_member0.Value495))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(140) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, iDiscovery_PreVariable_27))) {
				Verify.incrementCounter(140);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, \\old(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(141) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913))) {
				Verify.incrementCounter(141);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913)");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(142) < 1&& !(daikon.Quant.memberOf(iDiscovery_PreVariable_72 , out2 ))) {
				Verify.incrementCounter(142);
				throw new AssertionError("daikon.Quant.memberOf(\\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_5557) , out2 )");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(143) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, iDiscovery_PreVariable_50))) {
				Verify.incrementCounter(143);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, \\old(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(144) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_20))) {
				Verify.incrementCounter(144);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Gain1195))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(145) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, 0.5))) {
				Verify.incrementCounter(145);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030, 0.5)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(146) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, iDiscovery_PreVariable_23))) {
				Verify.incrementCounter(146);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, \\old(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(147) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948))) {
				Verify.incrementCounter(147);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(148) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(148);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(149) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948))) {
				Verify.incrementCounter(149);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.v_Control_Law_100000084_class_member16.Value948)");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(150) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944))) {
				Verify.incrementCounter(150);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(151) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(151);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(152) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793))) {
				Verify.incrementCounter(152);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(153) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, iDiscovery_PreVariable_8))) {
				Verify.incrementCounter(153);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, \\old(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_8590))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(154) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072))) {
				Verify.incrementCounter(154);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1072)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(155) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, 0.006285533905932738))) {
				Verify.incrementCounter(155);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, 0.006285533905932738)");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(156) < 1&& !(daikon.Quant.pairwiseEqual(out1, new double[] { 0.0 }))) {
				Verify.incrementCounter(156);
				throw new AssertionError("daikon.Quant.pairwiseEqual(out1, new double[] { 0.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(157) < 1&& !(daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554))) {
				Verify.incrementCounter(157);
				throw new AssertionError("daikon.Quant.eltwiseGT(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554)");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(158) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, iDiscovery_PreVariable_21))) {
				Verify.incrementCounter(158);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913, \\old(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Gain918))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(159) < 1&& !(daikon.Quant.pairwiseEqual(out2, new double[] { 0.0, 0.0 }))) {
				Verify.incrementCounter(159);
				throw new AssertionError("daikon.Quant.pairwiseEqual(out2, new double[] { 0.0, 0.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(160) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, iDiscovery_PreVariable_4))) {
				Verify.incrementCounter(160);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, \\old(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(161) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, 2.0))) {
				Verify.incrementCounter(161);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, 2.0)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(162) < 1&& !(daikon.Quant.eltsLT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793))) {
				Verify.incrementCounter(162);
				throw new AssertionError("daikon.Quant.eltsLT(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(163) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(163);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(164) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030))) {
				Verify.incrementCounter(164);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain1030)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(165) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { 10.0, -10.0 }))) {
				Verify.incrementCounter(165);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.NumeratorCoefficients_3554, new double[] { 10.0, -10.0 })");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(166) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913))) {
				Verify.incrementCounter(166);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_10592, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Gain913)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(167) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(167);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.u_Control_Law_100000081_class_member17.Value944, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(168) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_9591, iDiscovery_PreVariable_11))) {
				Verify.incrementCounter(168);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.NumeratorTerms_9591, \\old(in2_1))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(169) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940))) {
				Verify.incrementCounter(169);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940)");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(170) < 1&& !(daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, iDiscovery_PreVariable_9))) {
				Verify.incrementCounter(170);
				throw new AssertionError("daikon.Quant.pairwiseEqual(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_4556, \\old(this.Reaction_Jet_Control_100000006_class_member0.DenominatorCoefficients_12616))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(171) < 1&& !(daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, 0.055))) {
				Verify.incrementCounter(171);
				throw new AssertionError("daikon.Quant.fuzzy.eq(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value940, 0.055)");
			}
			Verify.ignoreIf(true);
		}


		if(Verify.getBoolean()){
			if (Verify.getCounter(172) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, iDiscovery_PreVariable_71))) {
				Verify.incrementCounter(172);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_14618, \\old(in1_0))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(173) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793))) {
				Verify.incrementCounter(173);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.DenominatorTerms_6558, this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value793)");
			}
			Verify.ignoreIf(true);
		}



		if(Verify.getBoolean()){
			if (Verify.getCounter(174) < 1&& !(daikon.Quant.pairwiseEqual(out1, iDiscovery_PreVariable_59))) {
				Verify.incrementCounter(174);
				throw new AssertionError("daikon.Quant.pairwiseEqual(out1, \\old(out1))");
			}
			Verify.ignoreIf(true);
		}

		if(Verify.getBoolean()){
			if (Verify.getCounter(175) < 1&& !(daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, iDiscovery_PreVariable_10))) {
				Verify.incrementCounter(175);
				throw new AssertionError("daikon.Quant.fuzzy.ne(this.Reaction_Jet_Control_100000006_class_member0.Yaw_Control_Law_100000076_class_member15.Value928, \\old(in2_0))");
			}
			Verify.ignoreIf(true);
		}

	}
}
