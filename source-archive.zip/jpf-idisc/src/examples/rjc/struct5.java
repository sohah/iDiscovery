package rjc;

public class struct5 {
  public double signal1 = 0;
  public double signal2 = 0;
}

